import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Tyrogue",
		fr: "Débugant",
		de: "Rabauz"
	},

	illustrator: "Tomokazu Komiya",
	rarity: "Uncommon",
	category: "Pokemon",
	set: Set,
	cameoDexIds: [107, 237],

	dexId: [236],

	hp: 30,

	types: [
		"Fighting"
	],

	stage: "Baby",

	attacks: [
		{
			cost: [
				"Fighting",
			],

			name: {
				en: "Energy Punch",
				fr: "Poing énergétique",
				de: "Energiehieb"
			},

			effect: {
				en: "Flip a coin. If heads, discard a Special Energy card attached to the Defending Pokémon. If tails, this attack does nothing.",
				fr: "Lancez une pièce. Si c'est face, défaussez-vous d'une carte Énergie spéciale attachée au Pokémon Défenseur. Si c'est pile, cette attaque ne fait rien.",
				de: "Wirf eine Münze. Lege bei „Kopf“ 1 an das Verteidigende Pokémon angelegte Spezial-Energiekarte auf den Anlagestapel deines Gegners. Bei „Zahl“ hat dieser Angriff keine Auswirkungen."
			},

			damage: 10
		},
	],

	retreat: 1,

	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 90127,
				cardmarket: 275136
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 90127,
				cardmarket: 275136
			}
		},
	]
}

export default card
