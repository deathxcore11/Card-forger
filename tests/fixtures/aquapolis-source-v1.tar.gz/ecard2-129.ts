import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Metal Cube 01",
		fr: "Cube de métal 01",
		de: "Metall-Würfel 01"
	},

	illustrator: undefined,
	rarity: "Uncommon",
	category: "Trainer",
	set: Set,

	effect: {
		en: "Attach this card to 1 of your Metal Pokémon in play. That Pokémon may use this card's attack instead of its own. At the end of your turn, discard Metal Cube 01.",
		fr: "Attachez cette carte à l'un de vos Pokémon {M} en jeu. Ce Pokémon peut utiliser l'attaque de cette carte à la place de la sienne. À la fin de votre tour, défaussez-vous de Cube de métal 01.",
		de: "Lege diese Karte an 1 deiner {M}-Pokémon im Spiel an. Dieses Pokémon kann den Angriff dieser Karte anstatt seiner eigenen verwenden. Lege am Ende deines Zuges Metall-Würfel 01 auf deinen Ablagestapel."
	},

	attacks: [
		{
			name: {
				en: "Metal Reversal",
				de: "Metall-Umkehrung",
				fr: "Inversion métal"
			},
			damage: 10,
			effect: {
				en: "Before doing damage, you may choose 1 of your opponent's Benched Pokémon and switch it with the Defending Pokémon.",
				de: "Bevor Schaden zugefügt wird, kannst du 1 der Pokémon auf der Bank deines Gegners wählen und es mit dem Verteidigenden Pokémon austauschen.",
				fr: "Avant d'infliger les dégâts, vous pouvez choisir un des Pokémon du Banc de votre adversaire et l'échanger contre le Pokémon Défenseur."
			},
			cost: [
				"Metal",
			]
		},
	],

	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 87348,
				cardmarket: 275205
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 87348,
				cardmarket: 275205
			}
		},
	]
}

export default card
