import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Sudowoodo",
		fr: "Simularbre",
		de: "Mogelbaum"
	},

	illustrator: "Kagemaru Himeno",
	rarity: "Rare",
	category: "Pokemon",
	set: Set,

	dexId: [185],

	hp: 60,

	types: [
		"Fighting"
	],

	stage: "Basic",

	attacks: [
		{
			cost: [
				"Colorless",
			],
			name: {
				en: "Copy",
				fr: "Copiage",
				de: "Kopie"
			},
			effect: {
				en: "Choose 1 of the Defending Pokémon's attacks. Copy copies that attack. This attack does nothing if Sudowoodo doesn't have the Energy necessary to use that attack. (You must still do anything else required in order to use that attack.)",
				fr: "Choisissez une des attaques du Pokémon Défenseur. Copiage copie cette attaque. Cette attaque ne fait rien si Simularbre n'a pas l'Énergie nécessaire pour utiliser cette attaque. (Vous devez toujours accomplir les autres actions afin d'utiliser cette attaque.)",
				de: "Wähle 1 der Angriff des Verteidigenden Pokémon. Kopie kopiert diesen Angriff. Dieser Angriff hat keine Auswirkungen, wenn an Mogelbaum nicht die für diesen Angriff benötigte Energie angelegt ist. (Du musst immer noch alles tun, was verlangt wird, um diesen Angriff durchzuführen.)"
			},

		},
		{
			cost: [
				"Fighting",
			],
			name: {
				en: "Energy Draw",
				fr: "Absorption d'énergie",
				de: "Energieanziehung"
			},
			effect: {
				en: "Search your deck for a basic Energy card and attach it to Sudowoodo. Shuffle your deck afterward.",
				fr: "Cherchez dans votre deck une carte Énergie de base et attachez-la à Simularbre. Mélangez ensuite votre deck.",
				de: "Du kannst dein Deck nach einer Basis-Energiekarte durchsuchen und sie an Mogelbaum anlegen. Mische dein Deck danach."
			},

		},
	],

	weaknesses: [
		{
			type: "Water",
			value: "x2"
		},
	],
	retreat: 2,


	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 89591,
				cardmarket: 275046
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 89591,
				cardmarket: 275046
			}
		},
	]
}

export default card
