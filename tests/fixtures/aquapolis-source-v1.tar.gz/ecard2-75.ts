import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Eevee",
		fr: "Évoli",
		de: "Evoli"
	},

	illustrator: "Midori Harada",
	rarity: "Common",
	category: "Pokemon",
	set: Set,

	dexId: [133],

	hp: 50,

	types: [
		"Colorless"
	],

	stage: "Basic",

	attacks: [
		{
			cost: [
				"Colorless",
			],
			name: {
				en: "Charge Up",
				fr: "Chargement",
				de: "Aufladen"
			},
			effect: {
				en: "Flip a coin. If heads, search your deck for an Energy card and attach it to Eevee. Shuffle your deck afterward.",
				fr: "Lancez une pièce. Si c'est face, vous pouvez chercher une carte Énergie et l'attacher à Évoli. Mélangez ensuite votre deck.",
				de: "Wirf eine Münze. Durchsuche bei „Kopf“ dein Deck nach einer Energiekarte und lege sie an Evoli an. Mische dein Deck danach."
			},

		},
		{
			cost: [
				"Colorless",
			],

			name: {
				en: "Lunge",
				fr: "Coup rapide",
				de: "Ausfall"
			},

			effect: {
				en: "Flip a coin. If tails, this attack does nothing.",
				fr: "Lancez une pièce. Si c'est pile, cette attaque ne fait rien.",
				de: "Wirf eine Münze. Bei „Zahl“ hat dieser Angriff keine Auswirkungen."
			},

			damage: 20
		},
	],

	weaknesses: [
		{
			type: "Fighting",
			value: "x2"
		},
	],
	retreat: 1,


	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 85080,
				cardmarket: 275149
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 85080,
				cardmarket: 275149
			}
		},
	]
}

export default card
