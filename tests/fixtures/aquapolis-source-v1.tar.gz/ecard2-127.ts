import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Lightning Cube 01",
		fr: "Cube électrik 01",
		de: "Elektro-Würfel 01"
	},

	illustrator: undefined,
	rarity: "Uncommon",
	category: "Trainer",
	set: Set,

	effect: {
		en: "Attach this card to 1 of your Lightning Pokémon in play. That Pokémon may use this card's attack instead of its own. At the end of your turn, discard Lightning Cube 01.",
		fr: "Attachez cette carte à l'un de vos Pokémon {L} en jeu. Ce Pokémon peut utiliser l'attaque de cette carte à la place de la sienne. À la fin de votre tour, défaussez-vous de Cube électrik 01.",
		de: "Lege diese Karte an 1 deine {L}-Pokémon im Spiel an. Dieses Pokémon kann den Angriff dieser Karte anstatt seiner eigenen verwenden. Lege am Ende deines Zuges Blitz-Würfel 01 auf deinen Ablagestapel."
	},

	attacks: [
		{
			name: {
				en: "Discharge",
				de: "Entladung",
				fr: "Décharge"
			},
			damage: "40×",
			effect: {
				en: "Discard all Lightning Energy cards attached to this Pokémon. Then, flip a number of coins equal to the number of Energy cards discarded that way. This attack does 40 damage times the number of heads.",
				de: "Du kannst alle {L}-Energiekarten, die an dieses Pokémon angelegt sind, auf deinen Ablagestapel legen. Wirf dann eine Anzahl Münzen gleich der Anzahl der auf diese Weise abgelegten Energiekarten. Dieser Angriff fügt 40 Schadenspunkte mal der Anzahl „Kopf“ zu.",
				fr: "Défaussez-vous de toutes les cartes Énergie {L} attachées à ce Pokémon. Lancez ensuite un nombre de pièces égal au nombre de cartes Énergie que vous avez défaussé de cette manière. Cette attaque fait 40 dégâts multipliés par le nombre de faces."
			},
			cost: [
				"Lightning",
			]
		},
	],

	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 86754,
				cardmarket: 275203
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 86754,
				cardmarket: 275203
			}
		},
	]
}

export default card
