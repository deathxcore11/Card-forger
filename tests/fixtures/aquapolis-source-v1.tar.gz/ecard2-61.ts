import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Smoochum",
		fr: "Lippouti",
		de: "Kussilla"
	},

	illustrator: "Kagemaru Himeno",
	rarity: "Uncommon",
	category: "Pokemon",
	set: Set,

	dexId: [238],

	hp: 30,

	types: [
		"Psychic"
	],

	stage: "Baby",

	attacks: [
		{
			cost: [
				"Psychic",
			],
			name: {
				en: "Energy Kiss",
				fr: "Bisou d'énergie",
				de: "Energiekuss"
			},
			effect: {
				en: "Flip a number of coins equal to the number of Energy cards attached to the Defending Pokémon. This attack does 10 damage times the number of heads.",
				fr: "Lancez un nombre de pièces égal au nombre de cartes Énergie attachées au Pokémon Défenseur. Cette attaque inflige 10 dégâts multipliés par le nombre de faces.",
				de: "Wirf so viele Münzen, wie Energiekarten an das Verteidigende Pokémon angelegt sind. Dieser Angriff fügt 10 Schadenspunkte mal der Anzahl „Kopf“ zu."
			},
			damage: "10×",

		},
	],

	retreat: 1,

	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 89360,
				cardmarket: 275134
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 89360,
				cardmarket: 275134
			}
		},
	]
}

export default card
