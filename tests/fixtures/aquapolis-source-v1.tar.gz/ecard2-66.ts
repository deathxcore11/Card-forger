import { Card } from '../../../interfaces'
import Set from '../Aquapolis'

const card: Card = {
	name: {
		en: "Wooper",
		fr: "Axoloto",
		de: "Felino"
	},

	illustrator: "Atsuko Nishida",
	rarity: "Uncommon",
	category: "Pokemon",
	set: Set,

	dexId: [194],

	hp: 50,

	types: [
		"Water"
	],

	stage: "Basic",

	attacks: [
		{
			cost: [
				"Colorless",
			],
			name: {
				en: "Tail Whap",
				fr: "Queue battoir",
				de: "Schweifvertrimmerer"
			},

			damage: 10,

		},
		{
			cost: [
				"Water",
			],
			name: {
				en: "Deep Dive",
				fr: "Gros plongeon",
				de: "Tieftaucher"
			},
			effect: {
				en: "Flip 3 coins. For each heads, remove 1 damage counter on Wooper.",
				fr: "Lancez 3 pièces. Pour chaque face, retirez un marqueur de dégâts de Axoloto.",
				de: "Wirf 3 Münzen. Entferne für jedesmal „Kopf“ eine Schadensmarke von Felino."
			},

		},
	],

	weaknesses: [
		{
			type: "Grass",
			value: "x2"
		},
	],
	retreat: 1,


	variants: [
		{
			type: 'normal',
			thirdParty: {
				tcgplayer: 90630,
				cardmarket: 275139
			}
		},
		{
			type: 'reverse',
			thirdParty: {
				tcgplayer: 90630,
				cardmarket: 275139
			}
		},
	]
}

export default card
